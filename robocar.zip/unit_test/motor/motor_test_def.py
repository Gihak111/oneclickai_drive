import os
import RPi.GPIO as GPIO
import numpy as np
from time import sleep

GPIO.setwarnings(False) # GPIO 경고 메시지 끄기
GPIO.setmode(GPIO.BCM)  # 핀번호 설정을 BCM모드로 설정

# LEFT Forward motor 설정
LEFT_FORWARD_PIN1 = 27
LEFT_FORWARD_PIN2 = 17
LEFT_FORWARD_PWM = 22

# LEFT Backward motor 설정
LEFT_BACKWARD_PIN1 = 6
LEFT_BACKWARD_PIN2 = 5
LEFT_BACKWARD_PWM = 13

# RIGHT Forward motor 설정
RIGHT_FORWARD_PIN1 = 20
RIGHT_FORWARD_PIN2 = 21
RIGHT_FORWARD_PWM = 16

# RIGHT Backward motor 설정
RIGHT_BACKWARD_PIN1 = 8
RIGHT_BACKWARD_PIN2 = 7
RIGHT_BACKWARD_PWM = 25







# LEFT Forward motor GPIO 설정
GPIO.setup(LEFT_FORWARD_PIN1, GPIO.OUT)
GPIO.setup(LEFT_FORWARD_PIN2, GPIO.OUT)
GPIO.setup(LEFT_FORWARD_PWM, GPIO.OUT)
LEFT_FORWARD_MOTOR = GPIO.PWM(LEFT_FORWARD_PWM, 100)
LEFT_FORWARD_MOTOR.start(0)

# LEFT Backward motor GPIO 설정
GPIO.setup(LEFT_BACKWARD_PIN1, GPIO.OUT)
GPIO.setup(LEFT_BACKWARD_PIN2, GPIO.OUT)
GPIO.setup(LEFT_BACKWARD_PWM, GPIO.OUT)
LEFT_BACKWARD_MOTOR = GPIO.PWM(LEFT_BACKWARD_PWM, 100)
LEFT_BACKWARD_MOTOR.start(0)

# RIGHT Forward motor GPIO 설정
GPIO.setup(RIGHT_FORWARD_PIN1, GPIO.OUT)
GPIO.setup(RIGHT_FORWARD_PIN2, GPIO.OUT)
GPIO.setup(RIGHT_FORWARD_PWM, GPIO.OUT)
RIGHT_FORWARD_MOTOR = GPIO.PWM(RIGHT_FORWARD_PWM, 100)
RIGHT_FORWARD_MOTOR.start(0)

# RIGHT Backward motor GPIO 설정
GPIO.setup(RIGHT_BACKWARD_PIN1, GPIO.OUT)
GPIO.setup(RIGHT_BACKWARD_PIN2, GPIO.OUT)
GPIO.setup(RIGHT_BACKWARD_PWM, GPIO.OUT)
RIGHT_BACKWARD_MOTOR = GPIO.PWM(RIGHT_BACKWARD_PWM, 100)
RIGHT_BACKWARD_MOTOR.start(0)

# 왼쪽 전방 모터 제어: 1, 0, 속도(0~100)
def leftForwardMotor(pin1, pin2, pwm):
    LEFT_FORWARD_MOTOR.ChangeDutyCycle(pwm)
    GPIO.output(LEFT_FORWARD_PIN1, pin1)
    GPIO.output(LEFT_FORWARD_PIN2, pin2)

# 왼쪽 후방 모터 제어: 1, 0, 속도(0~100)
def leftBackwardMotor(pin1, pin2, pwm):
    LEFT_BACKWARD_MOTOR.ChangeDutyCycle(pwm)
    GPIO.output(LEFT_BACKWARD_PIN1, pin1)
    GPIO.output(LEFT_BACKWARD_PIN2, pin2)

# 오른쪽 전방 모터 제어: 1, 0, 속도(0~100)
def rightForwardMotor(pin1, pin2, pwm):
    RIGHT_FORWARD_MOTOR.ChangeDutyCycle(pwm)
    GPIO.output(RIGHT_FORWARD_PIN1, pin1)
    GPIO.output(RIGHT_FORWARD_PIN2, pin2)

# 오른쪽 후방 모터 제어: 1, 0, 속도(0~100)
def rightBackwardMotor(pin1, pin2, pwm):
    RIGHT_BACKWARD_MOTOR.ChangeDutyCycle(pwm)
    GPIO.output(RIGHT_BACKWARD_PIN1, pin1)
    GPIO.output(RIGHT_BACKWARD_PIN2, pin2)

# 모든 모터 정지
def motor_stop():
    GPIO.output(LEFT_FORWARD_PIN1, False)
    GPIO.output(LEFT_FORWARD_PIN2, False)
    LEFT_FORWARD_MOTOR.ChangeDutyCycle(0)

    GPIO.output(LEFT_BACKWARD_PIN1, False)
    GPIO.output(LEFT_BACKWARD_PIN2, False)
    LEFT_BACKWARD_MOTOR.ChangeDutyCycle(0)

    GPIO.output(RIGHT_FORWARD_PIN1, False)
    GPIO.output(RIGHT_FORWARD_PIN2, False)
    RIGHT_FORWARD_MOTOR.ChangeDutyCycle(0)

    GPIO.output(RIGHT_BACKWARD_PIN1, False)
    GPIO.output(RIGHT_BACKWARD_PIN2, False)
    RIGHT_BACKWARD_MOTOR.ChangeDutyCycle(0)


# 테스트 코드
if __name__ == '__main__':
    # ~ leftForwardMotor(1, 0, 10)  # 전진
    # ~ leftBackwardMotor(1, 0, 10)  # 전진
    # ~ rightForwardMotor(1, 0, 20)  # 전진
    # ~ rightBackwardMotor(1, 0, 20)  # 전진
    # ~ sleep(10)
    motor_stop()
    
    
    
    # 왼쪽 전방 모터 테스트
    leftForwardMotor(1, 0, 20)  # 전진
    sleep(3)
    leftForwardMotor(0, 1, 20)  # 후진
    sleep(3)
    motor_stop()

    sleep(1)

    # 왼쪽 후방 모터 테스트
    leftBackwardMotor(1, 0, 20)  # 전진
    sleep(3)
    leftBackwardMotor(0, 1, 20)  # 후진
    sleep(3)
    motor_stop()

    # ~ sleep(1)

    # 오른쪽 전방 모터 테스트
    rightForwardMotor(1, 0, 20)  # 전진
    sleep(3)
    rightForwardMotor(0, 1, 20)  # 후진
    sleep(3)
    motor_stop()

    sleep(1)

    # 오른쪽 후방 모터 테스트
    rightBackwardMotor(1, 0, 20)  # 전진
    sleep(3)
    rightBackwardMotor(0, 1, 20)  # 후진
    sleep(3)
    motor_stop()

    # TODO1
    # 모든 모터 동시에
    # 5초 전진,
    # 5초 후진,
    # 정지
