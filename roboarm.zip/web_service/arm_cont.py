import time
import board
import busio
from adafruit_pca9685 import PCA9685
from adafruit_motor import servo

# --- 1. 하드웨어 설정 ---
try:
    i2c = busio.I2C(board.SCL, board.SDA)
    pca = PCA9685(i2c)
    pca.frequency = 50
    servos = [servo.Servo(pca.channels[i], min_pulse=500, max_pulse=2500) for i in range(16)]
    PCA9685_AVAILABLE = True
except Exception as e:
    print(f"[Arm] PCA9685 초기화 실패: {e}")
    print("[Arm] 서보 제어 비활성화 상태로 실행합니다.")
    servos = None
    PCA9685_AVAILABLE = False

# --- 2. 상태 변수 ---
# 핀 매핑: Base=0, Shoulder=1, Elbow=2, Gripper=3
JOINT_MAP = {'base': 0, 'shoulder': 1, 'elbow': 2, 'gripper': 3}

INITIAL_ANGLE = 90.0
current_angles = {'base': INITIAL_ANGLE, 'shoulder': INITIAL_ANGLE, 'elbow': INITIAL_ANGLE, 'gripper': INITIAL_ANGLE}

# 파라미터 (외부 제어용)
move_step = 2.0  # 한 번 키를 눌렀을 때(또는 루프당) 이동할 각도 크기


def init_arm():
    """모든 조인트를 초기 위치(90도)로 이동"""
    if not PCA9685_AVAILABLE:
        return
    for name, pin in JOINT_MAP.items():
        current_angles[name] = INITIAL_ANGLE
        servos[pin].angle = INITIAL_ANGLE
    print(f"[Arm] 초기화 완료: {current_angles}")


def set_params(step_size=2.0):
    """외부(API)에서 감도 조절"""
    global move_step
    move_step = float(step_size)
    print(f"[Arm] Speed set to: {move_step}")


def get_servo(joint=None):
    """현재 각도 조회 (전체 또는 특정 조인트)"""
    if joint is None:
        return current_angles.copy()
    return current_angles.get(joint)


def update_target(joint, delta):
    """목표 각도 업데이트 (delta만큼 증감) 후 즉시 하드웨어에 적용"""
    if joint not in JOINT_MAP:
        return
    new_angle = current_angles[joint] + delta
    new_angle = max(0, min(180, new_angle))
    print(f"[Arm] delta update {joint}: {current_angles[joint]:.1f} -> {new_angle:.1f}")
    current_angles[joint] = new_angle
    if PCA9685_AVAILABLE:
        servos[JOINT_MAP[joint]].angle = new_angle


def set_target_absolute(joint, angle):
    """목표 각도 절대값 설정 후 즉시 하드웨어에 적용"""
    if joint not in JOINT_MAP:
        return
    new_angle = max(0, min(180, angle))
    print(f"[Arm] absolute set {joint}: {current_angles[joint]:.1f} -> {new_angle:.1f}")
    current_angles[joint] = new_angle
    if PCA9685_AVAILABLE:
        servos[JOINT_MAP[joint]].angle = new_angle


if __name__ == '__main__':
    init_arm()
    print("암 테스트: 각 조인트를 0° → 90° → 180° → 90° 로 이동")
    for name in JOINT_MAP:
        for angle in [0, 90, 180, 90]:
            set_target_absolute(name, angle)
            print(f"  {name} = {angle}°")
            time.sleep(0.5)
    print("테스트 완료")
